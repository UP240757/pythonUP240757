@echo off
for /l %%i in (3,1,20) do (
    mkdir %%02i_Day
)
echo Carpetas creadas exitosamente.
pause
